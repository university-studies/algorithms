
/* Hlavi�kov� soubor pro c403.c - Vyhled�vac� tabulka v nese�azen�m 
poli se zar�kou, obsahuje jednak nutn� includes a externovan� prom�nn�,
ale rovne� definici datov�ch typ�. Tento soubor neupravujte! */

/* ********************** SOUBOR S HLAVI�KOU ********************** */
/* ********************** ------------------ ********************** */

/*  P�edm�t: Algoritmy (IAL) - FIT (Fakulta Informa�n�ch Technologi�)
    Hlavi�ka pro soubor: c403.c
    Vytvo�il: Martin Tu�ek, z��� 2005                                
    Upravil: Bohuslav K�ena, listopad 2009                           
    Upravil: Masarik Karel,  listopad 2010                           */
/* ***************************************************************** */


#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>

#define FALSE 0
#define TRUE 1
#define ASMaxSize 50                              /* Maxim�ln� velikost pole. */

int ASSize;          /* Pro ��ely testov�n� je vhodn� m�t mo�nost volby
                        velikosti pole, kter�m je vyhled�vac� tabulka
                        implementov�na. Fyzicky je deklarov�no pole o rozm�ru
                        ASMaxSize, ale p�i implementaci va�ich funkc� uva�ujte
                        velikost ASSize! */

extern int solved;
extern int errflg;
extern int ASCompNum;       /* Prom�nn�, kter� bude uchov�vat po�et porovn�n� */

                                                           /* polo�ka tabulky */
typedef struct { 
        int Cont;                                           /* u�ite�n� obsah */
        int Key;     	                                                /* kl�� */
} tASData;

                                  /* vyhled�vac� tabulka implementovan� polem */
typedef struct  {
   tASData arr[ASMaxSize];                         /* pole pro datov� polo�ky */
   int last;                           /* index posledn� vyu�it� polo�ky pole */
} tASTable;


/****prototypes*****/
void ASInit   (tASTable *);
int  ASSearch (tASTable *, int , int* );
void ASInsert (tASTable *, int, int );
/*******end of prototypes**************/

/* konec c403.h */
