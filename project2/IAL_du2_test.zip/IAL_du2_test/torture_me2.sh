#!/bin/sh
#11.11.2010 - cht�l bych podotknout �e hlavn� d�k pat�� �lov�ku co m� na fitu�ce nick
# jan.chvala vzal sem jeho skript z du1 a trochu upravil pro du2
#p�edem bych cht�l podotknout, �e tyto testy byly p�ebr�ny z FIT serveru a 
#fitu�ky z lo�sk�ch let a proto d�k pat�� n�komu jin�mu ne� m� :) j� jsem je 
#jenom slo�il dohromady. Taky bych cht�l ��ct, �e nep�eb�r�m ��dnou odpov�dnost
#za spr�vn� v�sledky ani m�lo bod� ve WISu.
#
#
#POKUD NAJDETE N�JAK� BUGY NEBO UD�L�TE LEP�� TESTY, TAK MI NAPI�TE - BUDOU SE HODIT :)
#
#
#sada test� pro prvn� dom�c� �kol do IALu
#soubor torture_me.sh mus� b�t um�st�n v adres��i, kter� obsahuje adres��e
#c401, c402, c403, kter� obsahuj� testovac� soubory, spr�vn� v�stupy, soubory  .c a .h
#a soubor Makefile
#
#
#skript postupn� projede adres��e, pomoc� make vytvo�� spustiteln� programy,
#programy spust� a jejich v�stupy ulo�� do soubor� .txt
#v�stupy porovn� s refen�n�mi a vytvo�� jejich rozd�l, kter� ulo�� do 
#p��slu�n�ho souboru diff*.txt (pokud je soubor nulov� velikosti, program 
#funguje spr�vn�)
#
#p�i spr�vn�m v�stupu se tak� provede ten na memory leaks valgrindem a jeho 
#v�sledek se vyp�e do souboru valgrind.txt a na termin�l
#pokud nen� v�stup spr�vn�, nakonec v�m program nab�dne rozd�ly soubor� vypsat 
#na termin�l
#
#
# 

for t in c401 c402 c403
do
  echo "################################################################################"
  echo "Running tests for "$t":"                                                       
  cd $t
    test1=$t-aastandard-test
    test2=$t-advanced-test
    rm $test1 $test2 2>/dev/null >/dev/null
    make
    chmod +x $test1
    chmod +x $test2
################### standard test #############################################
    echo -n "   standard test:"
    ./$test1 > $test1-result.txt
    diff $test1.output $test1-result.txt >diff-standard.txt
    if [ -s diff-standard.txt ]
      then  echo "      failed"
            echo "Do you want to check differences (Y/N)?"
            read x
            if [ "$x" = "Y" -o "$x" = "y" ]
              then
                cat diff-standard.txt
            fi
      else echo "      success"
          valgrind --log-file=valgrind.txt ./$test1 >/dev/null
          echo "     ---------------------------------------------------------------VALGRIND OUT"
          cat valgrind.txt | sed 's/^.*[=]/     |/g' | grep bytes 
          echo "     ---------------------------------------------------------------VALGRIND OUT"
    fi
################### advanced test #############################################
    echo -n "   advanced test:"
    ./$test2 > $test2-result.txt
    diff $test2.output $test2-result.txt >diff-advanced.txt
    if [ -s diff-advanced.txt ]
      then  echo "      failed"
            echo "Do you want to check differences (Y/N)?"
            read x
            if [ "$x" = "Y" -o "$x" = "y" ]
              then
                cat diff-advanced.txt
            fi
      else echo "      success"
          valgrind --log-file=valgrind.txt ./$test2 >/dev/null
          echo "     ---------------------------------------------------------------VALGRIND OUT"
          cat valgrind.txt | sed 's/^.*[=]/     |/g' | grep bytes 
          echo "     ---------------------------------------------------------------VALGRIND OUT"
    fi
        
  cd ..
  echo ""
done
echo "Do you want to remove temporary files (Y/N)?"
read x
if [ "$x" = "Y" -o "$x" = "y" ]
  then
    rm -f c401/*.txt c402/*.txt c403/*.txt
    rm -f c401/c401-aastandard-test c401/c401-advanced-test
    rm -f c402/c402-aastandard-test c402/c402-advanced-test
    rm -f c403/c403-aastandard-test c403/c403-advanced-test 
fi   
############################## END ############################################
